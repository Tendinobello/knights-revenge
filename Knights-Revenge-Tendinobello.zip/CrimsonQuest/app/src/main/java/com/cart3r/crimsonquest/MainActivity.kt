package com.cart3r.crimsonquest

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.cart3r.crimsonquest.ui.GameScreen
import com.cart3r.crimsonquest.ui.theme.CrimsonTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CrimsonTheme {
                GameScreen()
            }
        }
    }
}
