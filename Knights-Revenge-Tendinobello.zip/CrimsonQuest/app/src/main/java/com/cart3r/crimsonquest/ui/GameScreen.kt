package com.cart3r.crimsonquest.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

private val Night = Color(0xFF100D18)
private val Crimson = Color(0xFFFF4058)
private val Gold = Color(0xFFFFD166)

@Composable
fun GameScreen() {
    var knightX by remember { mutableFloatStateOf(0.22f) }
    var enemyX by remember { mutableFloatStateOf(0.82f) }
    var score by remember { mutableIntStateOf(0) }
    var lives by remember { mutableIntStateOf(3) }
    var jump by remember { mutableFloatStateOf(0f) }
    var attackFlash by remember { mutableFloatStateOf(0f) }
    var message by remember { mutableStateOf("A monster approaches. Defend the kingdom!") }
    var gameOver by remember { mutableStateOf(false) }
    var lastFrame by remember { mutableLongStateOf(0L) }

    fun restart() {
        knightX = 0.22f
        enemyX = 0.82f
        score = 0
        lives = 3
        jump = 0f
        attackFlash = 0f
        message = "A monster approaches. Defend the kingdom!"
        gameOver = false
        lastFrame = 0L
    }

    LaunchedEffect(gameOver) {
        while (!gameOver) {
            withFrameNanos { frame ->
                if (lastFrame == 0f) {
                    lastFrame = frame.toFloat()
                } else {
                    val dt = ((frame.toFloat() - lastFrame) / 1_000_000_000f).coerceIn(0f, 0.05f)
                    lastFrame = frame.toFloat()
                    if (jump > 0f) jump = (jump - dt * 1.7f).coerceAtLeast(0f)
                    if (attackFlash > 0f) attackFlash = (attackFlash - dt * 3.5f).coerceAtLeast(0f)

                    enemyX -= dt * (0.055f + score * 0.002f)
                    if (enemyX < 0.04f) {
                        enemyX = 0.86f
                        lives -= 1
                        message = "The monster got past you!"
                        if (lives <= 0) {
                            gameOver = true
                            message = "The quest is over. Try again!"
                        }
                    }
                }
            }
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Night) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "KNIGHT'S REVENGE",
                color = Crimson,
                fontSize = 25.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 2.sp
            )
            Text("CREATED BY TENDINOBELLO", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text("A tiny 2D fantasy adventure", color = Color(0xFFBEB4C8), fontSize = 12.sp)
            Spacer(Modifier.height(14.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("⭐ SCORE: $score", color = Gold, fontWeight = FontWeight.Bold)
                Text("❤ LIVES: $lives", color = Color(0xFFFF8290), fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))

            Canvas(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color(0xFF21192C), RoundedCornerShape(18.dp))
            ) {
                val w = size.width
                val h = size.height
                // Moon and distant castle silhouettes
                drawCircle(Color(0xFFFFE7A3), radius = w * 0.055f, center = Offset(w * 0.82f, h * 0.16f))
                drawRect(Color(0xFF30243C), topLeft = Offset(0f, h * 0.52f), size = Size(w, h * 0.32f))
                for (i in 0..4) {
                    val x = w * (0.08f + i * 0.22f)
                    drawRect(Color(0xFF191522), Offset(x, h * 0.36f), Size(w * 0.11f, h * 0.34f))
                    drawRect(Color(0xFF191522), Offset(x - w * 0.02f, h * 0.31f), Size(w * 0.15f, h * 0.06f))
                }
                // Ground
                drawRect(Color(0xFF493344), Offset(0f, h * 0.83f), Size(w, h * 0.17f))
                drawRect(Color(0xFF6D4B4D), Offset(0f, h * 0.83f), Size(w, h * 0.018f))

                val floor = h * 0.82f
                val px = w * knightX
                val py = floor - jump * h * 0.22f
                // Knight: helmet, armor, legs, shield and sword
                drawCircle(Color(0xFFC9D2E2), w * 0.045f, Offset(px, py - h * 0.19f))
                drawRect(Color(0xFF7C8AA5), Offset(px - w * 0.052f, py - h * 0.15f), Size(w * 0.104f, h * 0.12f))
                drawRect(Color(0xFF414D68), Offset(px - w * 0.045f, py - h * 0.035f), Size(w * 0.035f, h * 0.07f))
                drawRect(Color(0xFF414D68), Offset(px + w * 0.012f, py - h * 0.035f), Size(w * 0.035f, h * 0.07f))
                drawRect(Color(0xFFB8C6D9), Offset(px - w * 0.025f, py - h * 0.205f), Size(w * 0.05f, h * 0.012f))
                drawRect(Color(0xFF9D3346), Offset(px - w * 0.07f, py - h * 0.13f), Size(w * 0.025f, h * 0.10f))
                val swordEndX = px + w * if (attackFlash > 0f) 0.19f else 0.10f
                val swordEndY = py - h * if (attackFlash > 0f) 0.15f else 0.10f
                drawLine(Color(0xFFE8EDF5), Offset(px + w * 0.045f, py - h * 0.11f), Offset(swordEndX, swordEndY), strokeWidth = w * 0.012f)
                drawLine(Gold, Offset(px + w * 0.04f, py - h * 0.12f), Offset(px + w * 0.07f, py - h * 0.09f), strokeWidth = w * 0.018f)

                // Cartoon monster
                val ex = w * enemyX
                val ey = floor
                drawCircle(Color(0xFF65B56D), w * 0.065f, Offset(ex, ey - h * 0.085f))
                drawCircle(Color.White, w * 0.012f, Offset(ex - w * 0.023f, ey - h * 0.095f))
                drawCircle(Color.White, w * 0.012f, Offset(ex + w * 0.023f, ey - h * 0.095f))
                drawCircle(Color(0xFF24202B), w * 0.006f, Offset(ex - w * 0.023f, ey - h * 0.095f))
                drawCircle(Color(0xFF24202B), w * 0.006f, Offset(ex + w * 0.023f, ey - h * 0.095f))
                drawRect(Color(0xFF3E814A), Offset(ex - w * 0.045f, ey - h * 0.025f), Size(w * 0.09f, h * 0.025f))
                drawCircle(Color(0xFFB6E5A4), w * 0.012f, Offset(ex - w * 0.035f, ey - h * 0.145f))
                drawCircle(Color(0xFFB6E5A4), w * 0.012f, Offset(ex + w * 0.035f, ey - h * 0.145f))

                if (attackFlash > 0f) {
                    drawCircle(Crimson.copy(alpha = 0.35f), w * 0.17f, Offset(px + w * 0.12f, py - h * 0.12f), style = Stroke(width = w * 0.012f))
                }
            }

            Spacer(Modifier.height(10.dp))
            Text(message, color = Color(0xFFE5DCE8), fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))

            if (gameOver) {
                Button(onClick = { restart() }, colors = ButtonDefaults.buttonColors(containerColor = Crimson)) {
                    Text("PLAY AGAIN", fontWeight = FontWeight.Bold)
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { knightX = (knightX - 0.055f).coerceAtLeast(0.10f) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF373044))
                    ) { Text("◀") }
                    Button(
                        onClick = { jump = 1f },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF373044))
                    ) { Text("JUMP") }
                    Button(
                        onClick = { knightX = (knightX + 0.055f).coerceAtMost(0.65f) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF373044))
                    ) { Text("▶") }
                    Button(
                        onClick = {
                            attackFlash = 1f
                            if (abs(enemyX - knightX) < 0.23f) {
                                score += 10
                                enemyX = 0.88f
                                message = "Monster defeated! +10 points"
                            } else {
                                message = "Move closer to reach the monster."
                            }
                        },
                        modifier = Modifier.weight(1.25f),
                        colors = ButtonDefaults.buttonColors(containerColor = Crimson)
                    ) { Text("⚔ HIT", fontWeight = FontWeight.Bold) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Move • Jump • Strike", color = Color(0xFF92879A), fontSize = 11.sp)
        }
    }
}
