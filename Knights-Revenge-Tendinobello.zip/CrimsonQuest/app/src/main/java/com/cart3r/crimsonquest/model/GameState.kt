package com.cart3r.crimsonquest.model

data class GameState(
    val guessText: String = "",
    val attemptsLeft: Int = 5,
    val score: Int = 0,
    val message: String = "A secret number is hidden between 1 and 20.",
    val gameOver: Boolean = false,
    val won: Boolean = false
)
