package com.cart3r.crimsonquest.data

import kotlinx.coroutines.flow.Flow

class GameRepository(private val dao: GameDao) {
    val recentGames: Flow<List<GameEntity>> = dao.observeRecentGames()

    suspend fun saveGame(score: Int, won: Boolean) {
        dao.insert(GameEntity(score = score, won = won))
    }
}
