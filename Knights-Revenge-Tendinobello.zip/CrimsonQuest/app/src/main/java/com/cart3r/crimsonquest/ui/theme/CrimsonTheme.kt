package com.cart3r.crimsonquest.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CrimsonColors = darkColorScheme(
    primary = Color(0xFFFF4058),
    onPrimary = Color(0xFFFFFFFF),
    secondary = Color(0xFFFF8795),
    background = Color(0xFF090609),
    surface = Color(0xFF171017),
    onBackground = Color(0xFFF7EDF0),
    onSurface = Color(0xFFF7EDF0)
)

@Composable
fun CrimsonTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = CrimsonColors,
        content = content
    )
}
