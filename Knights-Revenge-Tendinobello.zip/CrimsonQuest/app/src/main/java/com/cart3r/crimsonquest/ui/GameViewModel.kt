package com.cart3r.crimsonquest.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cart3r.crimsonquest.data.GameEntity
import com.cart3r.crimsonquest.data.GameRepository
import com.cart3r.crimsonquest.model.GameState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

class GameViewModel(private val repository: GameRepository) : ViewModel() {
    private var secretNumber: Int = newSecret()

    private val _state = MutableStateFlow(GameState())
    val state: StateFlow<GameState> = _state.asStateFlow()

    private val _history = MutableStateFlow<List<GameEntity>>(emptyList())
    val history: StateFlow<List<GameEntity>> = _history.asStateFlow()

    val bestScore: Int
        get() = _history.value.maxOfOrNull { it.score } ?: 0

    init {
        viewModelScope.launch {
            repository.recentGames.collect { _history.value = it }
        }
    }

    fun onGuessChanged(value: String) {
        if (value.length <= 2 && value.all { it.isDigit() }) {
            _state.update { it.copy(guessText = value) }
        }
    }

    fun submitGuess() {
        val current = _state.value
        if (current.gameOver) return

        val guess = current.guessText.toIntOrNull()
        if (guess == null || guess !in 1..20) {
            _state.update { it.copy(message = "Enter a number from 1 to 20.") }
            return
        }

        val remaining = current.attemptsLeft - 1
        when {
            guess == secretNumber -> finishGame(
                won = true,
                attemptsLeft = remaining,
                message = "Correct! You found the secret number."
            )
            remaining == 0 -> finishGame(
                won = false,
                attemptsLeft = 0,
                message = "Game over! The secret number was $secretNumber."
            )
            guess < secretNumber -> _state.update {
                it.copy(
                    guessText = "",
                    attemptsLeft = remaining,
                    message = "Too low. Try a higher number!"
                )
            }
            else -> _state.update {
                it.copy(
                    guessText = "",
                    attemptsLeft = remaining,
                    message = "Too high. Try a lower number!"
                )
            }
        }
    }

    private fun finishGame(won: Boolean, attemptsLeft: Int, message: String) {
        val points = if (won) attemptsLeft * 20 else 0
        _state.update {
            it.copy(
                guessText = "",
                attemptsLeft = attemptsLeft,
                score = points,
                message = message,
                gameOver = true,
                won = won
            )
        }
        viewModelScope.launch {
            repository.saveGame(score = points, won = won)
        }
    }

    fun newGame() {
        secretNumber = newSecret()
        _state.value = GameState()
    }

    private fun newSecret(): Int = Random.nextInt(from = 1, until = 21)
}
