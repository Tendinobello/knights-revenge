package com.cart3r.crimsonquest.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface GameDao {
    @Insert
    suspend fun insert(game: GameEntity)

    @Query("SELECT * FROM games ORDER BY playedAt DESC LIMIT 10")
    fun observeRecentGames(): Flow<List<GameEntity>>
}
