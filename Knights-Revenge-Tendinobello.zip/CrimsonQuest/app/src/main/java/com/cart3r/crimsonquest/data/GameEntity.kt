package com.cart3r.crimsonquest.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "games")
data class GameEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val score: Int,
    val won: Boolean,
    val playedAt: Long = System.currentTimeMillis()
)
