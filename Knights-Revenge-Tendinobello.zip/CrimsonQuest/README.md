# Knight's Revenge

A small 2D fantasy action game for Android, built with Kotlin and Jetpack Compose.

**Created by Tendinobello.**

## Controls
- ◀ / ▶: move the knight
- JUMP: jump
- ⚔ HIT: swing the sword; defeat a nearby cartoon monster

## Gameplay
Defeat approaching fantasy monsters for points. If a monster gets past the knight, one life is lost. The game ends after three missed monsters.

## Run
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Use an emulator or Android device.
4. Press Run.

Requirements: JDK 17, Android SDK 35, minimum Android API 24.

This is a simple starter prototype. It uses Compose Canvas primitives for its graphics and does not yet include external sprite or audio assets.
